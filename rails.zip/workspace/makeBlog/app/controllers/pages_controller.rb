class PagesController < ApplicationController
  def home
  end

  def about
  end
  
  def directions
  end
end
