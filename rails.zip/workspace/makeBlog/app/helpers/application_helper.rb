module ApplicationHelper
    
    def get_season()
        
        time = Time.new
        
        if (time.month >= 3) && (time.month <= 5)
            "Yeah it is Spring"
        elsif (time.month >= 5) && (time.month <= 8)
            "Everyone Loves Summer"
        elsif (time.month >= 8) && (time.month <= 10)
           "Put on Your Jack"
        else
            "So Cold!!"
        end
    end
    
    def get_random_number(max_value = 10)
        rand(max_value)
    end
    
    def get_random_welcome()
        opening = ["Hello!",
                    "Ni Hao Ma?",
                    "I am good"]
         
        middle = ["Please keep learning",
                    "I know it's hard",
                    "but it's gonna be worthwhile"]
                    
        ending = ["Good Bye!",
                    "Don't give it up",
                    "You can do it!"]
        
        "#{opening[rand(3)]} #{middle[rand(3)]} #{ending[rand(3)]}"
    end
    
    def count_to_10()
        x = 2
        number_list = "1"
        
        loop do
            number_list = number_list + ", " + x.to_s
            x += 1
            break if x > 10
        end
        
        "#{number_list}"
    end
end
